
//import { Subject } from '../../../node_modules/rxjs/Subject';


export class displayFormService{
	
/*	//displaySubject = new Subject<int>();

	page:int=1;



  emitAppareilSubject() {
   // this.displaySubject.next(this.page.slice());
  }

	moveToPage2(){
		this.page = 2;
		 emitAppareilSubject();
	}


	moveToPage1(){
		this.page = 1;
		 emitAppareilSubject();
	}  */

}